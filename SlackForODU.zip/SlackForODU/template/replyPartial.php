<?php
$prevDate1 = '';
$replies = [];
if ($_SESSION['sess_user']) {
    if ('' != $channelSelected) {
//        usort($data['replies'], function ($a, $b) {
//            return strtotime($a['replied_at']) - strtotime($b['replied_at']);
//        });
        echo $value['replies'];
        foreach ($value['replies'] as $reply) {
            echo $reply;
            $crfdate = date_format(new DateTime($reply['replied_at']), 'l, F j, Y');
            $crdate = date_format(new DateTime($reply['replied_at']), 'g:i a');
            if (strcmp($crfdate, $prevDate1) > 0) {
                echo "<center>".$crfdate."</center>";
                $prevDate1 = $crfdate;
            }
            echo "<div class='chat-message clearfix'>";
        if($reply['profile_pic']){
//                        echo '<img src="data:image/jpeg;base64,'.base64_encode( $reply['profile_pic'] ).'"  alt="profile pic" width="24" height="24"/>';
//                    } else {
                        echo "<img src='../images/".$reply['profile_pic']."'  alt='profile pic' width='24' height='24'>";
                    }
            echo "<div class='chat-message-content clearfix'>";
            echo "<span class='chat-time''>".$crdate."</span>";
            echo  "<b>".ucwords($reply['replied_by'])."</b>";
            echo "<p>".$reply['reply_msg']."</p>";
    
            $plusReaction = [];
            $query = "SELECT * FROM Reply WHERE reply_id='" . $reply['reply_id'] . "' and reaction='+1'";
            $result = $connection->query($query);
            //echo $numrows;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    array_push($plusReaction, $row);
                }
            }
            $minusReaction = [];
            $query = "SELECT * FROM Reply WHERE reply_id='" . $reply['reply_id'] . "' and reaction='-1'";
            $result = $connection->query($query);
            //echo $numrows;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    array_push($minusReaction, $row);
                }
            }
            echo " </div>";
            echo " </div>";
            }
}
}
?>
        <form method="post">
            <fieldset>
                <div class="row">
                    <div class="col-sm-8 col-md-10 col-lg-10 col-xs-8">
                        <input type="text" placeholder="Reply here…" id="<?php echo " reply " . $value['msg_id'] ?>" name="reply_message" autofocus>
                    </div>
                    <div class="col-sm-4 col-md-2 col-lg-2 col-xs-4">
                        <input type="submit" value="Reply" class="btn reply" name="reply" id="<?php echo " msg " . $value['msg_id'] ?>"/>
                        <!-- style="position: absolute; left: -9999px"-->
                    </div>
                </div>
            </fieldset>
        </form>