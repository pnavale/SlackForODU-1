<?php
include 'includes/db_connection.php';
include 'includes/functions.php';
//include 'chatHistory.php';
include 'chats.php';
if (!isset($_SESSION)) {
    session_start();
}
?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700">
<div id="live-chat">
<header class="clearfix">
<!--            <a href="#" class="chat-close">x</a>-->
<h4><?php
    if ($channelSelected) {
    echo "#" . $channelSelected;
} else {
    echo ucwords($cname);
}
?></h4>
<span class="chat-message-counter">3</span>
</header>
<div class="chat">
    <div class="chat-history">
    <?php
        $prevDate = '';
//        usort($data['chats'], function ($a, $b) {
//            return strtotime($a['create_date']) - strtotime($b['create_date']);
//        });
        foreach ($data['chats'] as $value) {
            $crfdate = date_format(new DateTime($value['create_date']), 'l, F j, Y');
            $crdate = date_format(new DateTime($value['create_date']), 'g:i a');
            if (strcmp($crfdate, $prevDate) > 0) {
                echo "<center>".$crfdate."</center>";
                $prevDate = $crfdate;
            }  
             echo "<div class='chat-message clearfix'>";
            if($value['profile_pic']){
//                echo '<img src="data:image/jpeg;base64,'.base64_encode( $value['profile_pic'] ).'"  alt="profile pic" width="32" height="32"/>';
//            } else {
                echo "<img src='../images/". $value["profile_pic"] ."'  alt='profile pic' width='32' height='32'>";
            }
            echo "<div class='chat-message-content clearfix'>"; 
            echo "<span class='chat-time''>".$crdate."</span>";
            echo  "<b>".ucwords($value['creator_id'])."</b>";
            echo "<p>".$value['msg_body']."</p>";
//            echo "<a href='javascript:void(0);' data-href='member.php?emoji=+1&person='.$value["creator_id"].'&msgid='.$value["msg_id"].' class='emoji'>&#128077;</a><span>".count($value['plusReaction'])."</span>";
//            echo "<a href='javascript:void(0);' data-href='member.php?emoji=-1&person='.$value["creator_id"].'&msgid='.$value["msg_id"].' class='emoji'>&#128077;</a><span>".count($value['minusReaction'])."</span>";
             include 'replyPartial.php';
                       echo "</div>";
//                        <!-- end chat-message-content -->
                     echo "</div>";
//                    <!-- end chat-message -->
                    echo "<hr>";
        }
?>
            </div>
            <!-- end chat-history -->
            <!-- <p class="chat-feedback">Your partner is typing… </p>-->
            <form method="post">
                <fieldset>
                    <div class="row">
                        <div class="col-sm-8 col-md-10 col-lg-10 col-xs-8">
                            <input type="text" placeholder="Type your message…" name="message" autofocus>
                        </div>
                        <div class="col-sm-4 col-md-2 col-lg-2 col-xs-4">
                            <input type="submit" value="Send" class="btn" name="submit" />
                            <!--  style="position: absolute; left: -9999px"-->
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
        <!-- end chat -->
    </div>
    <!-- end live-chat -->
    <?php
if ($_SESSION['sess_user']) {
    if (isset($_POST['message'])) {
        if (!empty($_POST['message'])) {
            $message = verify_input($_POST['message']);
            $subject = $channelSelected;
            $creator_id = $_SESSION['sess_user'];
            if ($cname) {
                $channel_id = '';
                $recipient_id = $cname;
            } else {
                $channel_id = $channel_idSelected;
                $recipient_id = '';
            }
            $group_id = '';
            $profile_pic = $_SESSION['sess_user_profile_pic'];
            $sql = "insert into message (subject,creator_id,msg_body,create_date,channel_id,group_id,recipient_id,profile_pic)
        values('$subject','$creator_id','$message',NOW(),'$channel_id','$group_id','$recipient_id','$profile_pic')";
            if (mysqli_query($connection, $sql)) {
            } else if (mysqli_error($connection)) {
                echo "Error in posting a message.";
            }
            $_POST['message'] = '';
        }
        unset($_POST['message']);
        exit;
    }
}

?>
        <script type="text/javascript">
        $('.emoji').on('click', function(e) {
            console.log($(this).data('href'));
            var data = $(this).data('href');
            // member.php?emoji=+1&person=mater&msgid=8
            var url = data.substring(0, 10);
            var emoji = data.substring(17, 19);
            var msgid = data.substring(data.search('msgid=') + 6, data.length);
            var person = data.substring(27, data.search('&msgid='));

            $.ajax({
                type: 'GET',
                url: 'chat.php',
                data: { emoji: emoji, person: person, msgid: msgid },
                success: function(response) {
                    console.log({ emoji: emoji, person: person, msgid: msgid });
                    return { emoji: emoji, person: person, msgid: msgid };
                }
            });
            // $('.emoji').css('color','#9c7248');
        })
        $('.reply').on('click', function(e) {
            e.preventDefault();
            console.log($(this).attr('id'));
            console.log($(this).attr('id'));
            var msgId = this.id.substring(3, this.id.length);
            var replyInput = 'reply' + msgId;
            var replyInput = $('#' + replyInput).val();
            console.log(replyInput);
            console.log(msgId);
            $.ajax({
                type: 'GET',
                url: 'reply.php',
                data: {
                    msg_id: msgId,
                    reply: replyInput
                },
                success: function(response) {}
            });
        });
        </script>
        <?php
$profile = $_SESSION['sess_user_profile_pic'];
if ($_SESSION['sess_user']) {
    if (isset($_GET["emoji"]) || isset($_GET["person"]) || isset($_GET["msgid"])) {
        echo "nnjnjnj" . $_GET["emoji"] . $_GET["person"] . $_GET["msgid"];
        $emoji = $_GET["emoji"];
        $person = $_SESSION['sess_user'];
        $msgid = $_GET["msgid"];
        $msg_type = "reaction";
        $query = "SELECT * FROM Reply WHERE msg_id='" . $msgid . "' and reaction='" . $emoji . "' and replied_by='" . $person . "'";
        $result = $connection->query($query);
        if ($result->num_rows > 0) {
            echo "You can't like/dislike multiple times.";
        } else {
            $sql = "insert into Reply(msg_id,reply_msg,replied_by,replied_at,reaction,reply_type) values('$msgid','','$person',NOW(),'$emoji','$msg_type')";
            if (mysqli_query($connection, $sql)) {
                echo "Record updated successfully";
            } else {
                echo "Error updating record: " . mysqli_error($connection);
            }}
    }
    $profile = $_SESSION['sess_user_profile_pic'];
    if (isset($_POST["reply"]) && isset($_POST["reply_message"]) && isset($_GET["msg_id"])) {
        $replyMsg = $_POST["reply_message"];
        $msgid = $_GET["msg_id"];
        $msg_type = "reply";
        $replied_by = $_SESSION['sess_user'];
        // if($_SESSION['sess_user_profile_pic']){
        // $profile=$_SESSION['sess_user_profile_pic'];
        // }
        // else{
        //     $profile="person.png";
        // }
        global $profile;
        $sql = "insert into Reply(profile_pic,msg_id,reply_msg,replied_by,replied_at,reaction,reply_type) values('$profile','$msgid','$replyMsg','$replied_by',NOW(),'','$msg_type')";
        if (mysqli_query($connection, $sql)) {
            echo "Record updated successfully";
            echo $profile;
        } else {
            echo "Error updating record: " . mysqli_error($connection);
        }}
    // }}
}
mysqli_close($connection);
?>