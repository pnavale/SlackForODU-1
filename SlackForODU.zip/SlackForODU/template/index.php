<?php
header("Location: wklogin.php");
die();
?>
