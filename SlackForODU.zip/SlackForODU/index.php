<?php
header("Location: template/wklogin.php");
die();
?>
